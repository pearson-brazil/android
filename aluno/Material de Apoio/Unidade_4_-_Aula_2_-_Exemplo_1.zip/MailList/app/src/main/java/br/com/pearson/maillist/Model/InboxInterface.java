package br.com.pearson.maillist.Model;

/**
 * Created by pearson on 21/09/16.
 */
public interface InboxInterface {

    public void onComposeClicked();
}
